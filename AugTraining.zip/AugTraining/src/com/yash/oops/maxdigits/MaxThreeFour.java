package com.yash.oops.maxdigits;

public interface MaxThreeFour {
	void maxThreeDigit(int first,int last);
	void maxFourDigit(int first,int last);

}
