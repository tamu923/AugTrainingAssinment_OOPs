package com.yash.oops.calculations;

public abstract class A extends CalcAbs {

	@Override
	void sum(int a, int b) {
		System.out.println(a+b);
		
	}

	
}
