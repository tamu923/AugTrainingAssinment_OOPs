package com.yash.oops.calculations;

public abstract class B extends A {

	@Override
	void sub(int a, int b) {
		System.out.println(a-b);
	}

}
