package com.yash.oops.stringoperation;

public interface StringComparison {
	public void stringComparison(String first,String second);
}
