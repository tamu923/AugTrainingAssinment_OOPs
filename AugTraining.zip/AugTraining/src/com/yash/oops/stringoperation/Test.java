package com.yash.oops.stringoperation;

public class Test implements StringComparison{

	public static void main(String[] args) {
		StringComparison strComparison=new Test();
		strComparison.stringComparison("someshwar", "kharad");

	}

	@Override
	public void stringComparison(String first, String second) {
		char[] charFirst=first.toCharArray();
		char[] charSecond = second.toCharArray();
		for(int i=0;i<charFirst.length;i++) {
			for(int j=0;j<charSecond.length;j++) {
				if(charFirst[i]==charSecond[j]) {
					System.out.println(charFirst[i]+" "+charSecond[j]);
				}
			}
		}
	}

}
