package com.yash.oops.shapes;

import java.util.Scanner;

public class Rectangle implements Shape {

	Scanner sc=new Scanner(System.in);
	@Override
	public void area() {
		int a,b,c,h;
		int area;
		System.out.println("plz enter two point of contact for base ");
		b=sc.nextInt();
		a=sc.nextInt();
		System.out.println("plz enter height for rectangle ");
		h=sc.nextInt();
		c=b-a;
		area=c*h;
		System.out.println(area);
		
	}

}
