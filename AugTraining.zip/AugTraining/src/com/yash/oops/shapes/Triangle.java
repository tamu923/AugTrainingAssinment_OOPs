package com.yash.oops.shapes;

import java.util.Scanner;

public class Triangle implements Shape{
	
		Scanner sc=new Scanner(System.in);
	@Override
	public void area() {
		int a,b,c,d,e,f,g,h,i,j;
		int area;
		System.out.println("plz enter co-ordinate for point A ");
		a=sc.nextInt();
		b=sc.nextInt();
		System.out.println("plz enter co-ordinate for point B ");
		c=sc.nextInt();
		d=sc.nextInt();
		System.out.println("plz enter co-ordinate for point C ");
		e=sc.nextInt();
		f=sc.nextInt();
		
		g=a-c;
		h=b-d;
		
		i=a-e;
		j=b-f;
		
		area=((g*j)-(h*i)/2);
		System.out.println("area of triangle: "+area);
	}
	

}
