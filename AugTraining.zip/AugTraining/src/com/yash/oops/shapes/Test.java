package com.yash.oops.shapes;

public class Test {

	public static void main(String[] args) {
		Triangle triangle=new Triangle();
		//triangle.area();
		Square square=new Square();
		//square.area();
		Rectangle rectangle=new Rectangle();
		rectangle.area();
	}

}
