package com.yash.oops.shapes;

import java.util.Scanner;

public class Square implements Shape{
	
	Scanner sc=new Scanner(System.in);
	@Override
	public void area() {
		int x1,x2,y1,y2,side1,side2;;
		int area;
		System.out.println("plz enter x1 & x2 point ");
		x1=sc.nextInt();
		x2=sc.nextInt();
		System.out.println("plz enter y1 & y2 point ");
		y1=sc.nextInt();
		y2=sc.nextInt();
		side1=x2-x1;
		side2=y2-y1;
		area=side1*side2;
		System.out.println("area of square "+area);
	}

}
