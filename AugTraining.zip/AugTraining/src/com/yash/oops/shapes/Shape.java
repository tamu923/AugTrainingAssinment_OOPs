package com.yash.oops.shapes;

public interface Shape {
	public void area();

}
