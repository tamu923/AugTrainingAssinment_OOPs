public class ToFindPalindromeNum {

	static String str[]= {"nayan","ssad","akscfd"};
	static String resString[]= {"nayan","ssad","akscfd"};
	static boolean palindromeFlag=false;
	public static void main(String[] args) {
		ToFindPalindromeNum t= new ToFindPalindromeNum();
	for(String st:str)
	{
	t.toPalindromeNum(st);
	}
	}
	public void toPalindromeNum(String s)
	{
	char chArr[]=s.toCharArray();
	int n =chArr.length;
	int count=0;
	for(int i=0,j=chArr.length-1;i<chArr.length;i++,j--)
	{
	if(chArr[i]==chArr[j])
	{
	count++;
	}
	}
	if(count==n)
	{
	System.out.println("palindrom: "+s);
	}
	}

}
